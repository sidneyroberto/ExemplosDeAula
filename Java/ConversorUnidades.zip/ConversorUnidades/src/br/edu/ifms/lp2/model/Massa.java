/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifms.lp2.model;

/**
 *
 * @author sidneysousa
 */
public class Massa {
    
    public double converteDeQuiloParaGrama(double valorEmQuilo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeGramaParaQuilo(double valorEmGrama) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuiloParaOnca(double valorEmQuilo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeOncaParaQuilo(double valorEmOnca) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuiloParaLibra(double valorEmQuilo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeLibraParaQuilo(double valorEmLibra) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuiloParaQuilate(double valorEmQuilo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilateParaQuilo(double valorEmQuilate) {
        // Se vire!
        return 0;
    }
    
    public double converteDeGramaParaOnca(double valorEmGrama) {
        // Se vire!
        return 0;
    }
    
    public double converteDeOncaParaGrama(double valorEmOnca) {
        // Se vire!
        return 0;
    }
    
    public double converteDeGramaParaLibra(double valorEmGrama) {
        // Se vire!
        return 0;
    }
    
    public double converteDeLibraParaGrama(double valorEmLibra) {
        // Se vire!
        return 0;
    }
    
    public double converteDeGramaParaQuilate(double valorEmGrama) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilateParaGrama(double valorEmQuilate) {
        // Se vire!
        return 0;
    }
    
    public double converteDeOncaParaLibra(double valorEmOnca) {
        // Se vire!
        return 0;
    }
    
    public double converteDeLibraParaOnca(double valorEmLibra) {
        // Se vire!
        return 0;
    }
    
    public double converteDeOncaParaQuilate(double valorEmOnca) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilateParaOnca(double valorEmQuilate) {
        // Se vire!
        return 0;
    }
    
    public double converteDeLibraParaQuilate(double valorEmLibra) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilateParaLibra(double valorEmQuilate) {
        // Se vire!
        return 0;
    }
}
