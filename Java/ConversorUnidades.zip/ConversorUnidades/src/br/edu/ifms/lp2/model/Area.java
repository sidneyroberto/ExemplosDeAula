/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifms.lp2.model;

/**
 *
 * @author sidneysousa
 */
public class Area {
    
    public double converteDeMetroQuadradoParaQuilometroQuadrado(double valorEmMetroQuadrado) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroQuadradoParaMetroQuadrado(double valorEmQuilometroQuadrado) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroQuadradoParaHectare(double valorEmMetroQuadrado) {
        // Se vire!
        return 0;
    }
    
    public double converteDeHectareParaMetroQuadrado(double valorEmHectare) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroQuadradoParaAcre(double valorEmMetroQuadrado) {
        // Se vire!
        return 0;
    }
    
    public double converteDeAcreParaMetroQuadrado(double valorEmAcre) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroQuadradoParaHectare(double valorEmQuilometroQuadrado) {
        // Se vire!
        return 0;
    }
    
    public double converteDeHectareParaQuilometroQuadrado(double valorEmHectare) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroQuadradoParaAcre(double valorEmQuilometroQuadrado) {
        // Se vire!
        return 0;
    }
    
    public double converteDeAcreParaQuilometroQuadrado(double valorEmAcre) {
        // Se vire!
        return 0;
    }
    
    public double converteDeHectareParaAcre(double valorEmHectare) {
        // Se vire!
        return 0;
    }
    
    public double converteDeAcreParaHectare(double valorEmAcre) {
        // Se vire!
        return 0;
    }
}
