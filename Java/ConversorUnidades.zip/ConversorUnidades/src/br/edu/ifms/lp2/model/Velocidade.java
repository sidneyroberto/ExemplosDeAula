/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifms.lp2.model;

/**
 *
 * @author sidneysousa
 */
public class Velocidade {
    
    public double converteDeMetroPorSegundoParaQuilometroPorHora(double valorEmMetroPorSegundo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroPorHoraParaMetroPorSegundo(double valorEmQuilometroPorHora) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroPorSegundoParaMilhaPorHora(double valorEmMetroPorSegundo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaPorHoraParaMetroPorSegundo(double valorEmMilhaPorHora) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroPorSegundoParaPePorSegundo(double valorEmMetroPorSegundo) {
        // Se vire!
        return 0;
    }
    
    public double converteDePePorSegundoParaMetroPorSegundo(double valorEmPePorSegundo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroPorHoraParaMilhaPorHora(double valorEmQuilometroPorHora) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaPorHoraParaQuilometroPorHora(double valorEmMilhaPorHora) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroPorHoraParaPePorSegundo(double valorEmQuilometroPorHora) {
        // Se vire!
        return 0;
    }
    
    public double converteDePePorSegundoParaQuilometroPorHora(double valorEmPePorSegundo) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaPorHoraParaPePorSegundo(double valorEmMilhaPorHora) {
        // Se vire!
        return 0;
    }
    
    public double converteDePePorSegundoParaMilhaPorHora(double valorEmPePorSegundo) {
        // Se vire!
        return 0;
    }
}
