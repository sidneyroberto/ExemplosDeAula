/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.edu.ifms.lp2.model;

/**
 *
 * @author sidneysousa
 */
public class Comprimento {
    
    public double converteDeMetroParaQuilometro(double valorEmMetro) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroParaMetro(double valorEmQuilometro) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroParaMilha(double valorEmMetro) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaParaMetro(double valorEmMilha) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroParaJarda(double valorEmMetro) {
        // Se vire!
        return 0;
    }
    
    public double converteDeJardaParaMetro(double valorEmJarda) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMetroParaPe(double valorEmMetro) {
        // Se vire!
        return 0;
    }
    
    public double converteDePeParaMetro(double valorEmPe) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroParaMilha(double valorEmQuilometro) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaParaQuilometro(double valorEmMilha) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroParaJarda(double valorEmQuilometro) {
        // Se vire!
        return 0;
    }
    
    public double converteDeJardaParaQuilometro(double valorEmJarda) {
        // Se vire!
        return 0;
    }
    
    public double converteDeQuilometroParaPe(double valorEmQuilometro) {
        // Se vire!
        return 0;
    }
    
    public double converteDePeParaQuilometro(double valorEmPe) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaParaJarda(double valorEmMilha) {
        // Se vire!
        return 0;
    }
    
    public double converteDeJardaParaMilha(double valorEmJarda) {
        // Se vire!
        return 0;
    }
    
    public double converteDeMilhaParaPe(double valorEmMilha) {
        // Se vire!
        return 0;
    }
    
    public double converteDePeParaMilha(double valorEmPe) {
        // Se vire!
        return 0;
    }
    
    public double converteDeJardaParaPe(double valorEmJarda) {
        // Se vire!
        return 0;
    }
    
    public double converteDePeParaJarda(double valorEmPe) {
        // Se vire!
        return 0;
    }
}
